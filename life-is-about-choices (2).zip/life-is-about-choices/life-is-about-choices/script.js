function pilih(nilai, halaman){

    let skor = localStorage.getItem("skor");

    if(!skor){
        skor = 0;
    }

    skor = parseInt(skor) + nilai;

    localStorage.setItem("skor", skor);

    window.location.href = halaman;
}

function tampilHasil(){

    let skor = localStorage.getItem("skor");

    skor = parseInt(skor);

    let hasil = "";

    if(skor >= 12){

        hasil = "Kamu adalah tipe Bertanggung Jawab";

    } else if(skor >= 8){

        hasil = "Kamu adalah tipe Sedang Berproses";

    } else {

        hasil = "Kamu perlu Evaluasi Diri";
    }

    document.getElementById("hasil-text").innerText = hasil;
}